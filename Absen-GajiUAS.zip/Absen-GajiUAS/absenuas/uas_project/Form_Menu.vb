﻿Public Class Form_Menu

    Private Sub AbsensiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form_koneksi.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub GajiLemburToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form_Lembur.ShowDialog()
    End Sub

    Private Sub btnabsensi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form_koneksi.ShowDialog()
    End Sub

    Private Sub btnpenggajian_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpenggajian.Click
        Form_Gaji.ShowDialog()
    End Sub

    Private Sub btngajilembur_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngajilembur.Click
        Form_Lembur.ShowDialog()
    End Sub

    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Close()
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub
End Class